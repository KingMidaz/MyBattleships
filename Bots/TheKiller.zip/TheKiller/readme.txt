Written in C++, compile sln and run

-Bot decides where to shoot based on a probability density function
-Should a hit be scored the bot will change focus to destroying the ship
-Bot places ships randomly