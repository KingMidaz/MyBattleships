#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
#include <random>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include "rapidjson/document.h"

#include "Utility.h"
#include "Ships.h"
#include "Structs.h"

class MyBot {

};
// TODO: reference additional headers your program requires here
