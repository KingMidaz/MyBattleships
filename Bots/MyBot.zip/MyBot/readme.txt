Written in C++, compile sln and run

-Bot begins by firing along diagonals, first the centre diagonal and expanding out thereafter.
-Should a hit be registered the bot will attempt to find and destroy the hit ship
-Seeker missile will be fired when available, only special to have been implemented thus far
-Should all else fail a block will be selected randomly from those available